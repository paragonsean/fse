<?php
/**
 * Google API client exception.
 *
 * @package GoogleAnalytics
 */

/**
 * Google API Client exception.
 */
class Ga_Lib_Api_Client_Exception extends Exception {

}
