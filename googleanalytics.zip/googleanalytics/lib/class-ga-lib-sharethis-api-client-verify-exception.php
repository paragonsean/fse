<?php
/**
 * ShareThis API Client Verify exception.
 *
 * @package GoogleAnalytics
 */

/**
 * ShareThis API Client Verify exception.
 */
class Ga_Lib_Sharethis_Api_Client_Verify_Exception extends Ga_Lib_Sharethis_Api_Client_Exception {
}
