<?php
/**
 * ShareThis API Client Invite exception.
 *
 * @package GoogleAnalytics
 */

/**
 * ShareThis API Client Invite exception.
 */
class Ga_Lib_Sharethis_Api_Client_Invite_Exception extends Ga_Lib_Sharethis_Api_Client_Exception {
}
