<?php
/**
 * Google API client refresh token exception.
 *
 * @package GoogleAnalytics
 */

/**
 * Google API client refresh token exception.
 */
class Ga_Lib_Google_Api_Client_RefreshToken_Exception extends Ga_Lib_Google_Api_Client_Exception {
}
