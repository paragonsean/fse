<?php
/**
 * ShareThis API Client Alerts exception.
 *
 * @package GoogleAnalytics
 */

/**
 * ShareThis API Client Alerts exception.
 */
class Ga_Lib_Sharethis_Api_Client_Alerts_Exception extends Ga_Lib_Sharethis_Api_Client_Exception {
}
