<?php
/**
 * Google API request exception.
 *
 * @package GoogleAnalytics
 */

/**
 * Google API request exception.
 */
class Ga_Lib_Api_Request_Exception extends Exception {
}
