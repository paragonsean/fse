<?php
/**
 * Google API client account summaries exception.
 *
 * @package GoogleAnalytics
 */

/**
 * Google API client account summaries exception.
 */
class Ga_Lib_Google_Api_Client_AccountSummaries_Exception extends Ga_Lib_Google_Api_Client_Exception {
}
