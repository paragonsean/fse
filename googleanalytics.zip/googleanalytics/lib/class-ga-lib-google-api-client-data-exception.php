<?php
/**
 * Google API client data exception.
 *
 * @package GoogleAnalytics
 */

/**
 * Google API client data exception.
 */
class Ga_Lib_Google_Api_Client_Data_Exception extends Ga_Lib_Google_Api_Client_Exception {
}
