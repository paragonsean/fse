<?php
/**
 * ShareThis API Client Invalid Domain Exception.
 *
 * @package GoogleAnalytics
 */

/**
 * ShareThis API Client Invalid Domain Exception.
 */
class Ga_Lib_Sharethis_Api_Client_InvalidDomain_Exception extends Ga_Lib_Sharethis_Api_Client_Exception {
}
